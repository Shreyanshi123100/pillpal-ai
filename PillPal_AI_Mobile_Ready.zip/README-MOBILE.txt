PillPal AI mobile demo

IMPORTANT:
- Mobile browsers restrict speech unless the user taps the page first.
- Open the app, choose the language, then tap "Enable voice on this phone" once.
- For a real installable mobile experience, host this folder on HTTPS (GitHub Pages, Netlify, Vercel, etc.). Opening index.html directly from a ZIP/file manager is not the same as a web app and can block notifications/service workers.
- The selected-language voice must be installed on the phone's Text-to-Speech system. The app refuses to silently fall back to English for another selected language.
